#include <stdio.h>
#include <string.h>
#include <assert.h>

#include "mdadm.h"
#include "jbod.h"
#include "net.h"

int is_mounted;

// Obtain information about disk
uint32_t encodeOp(int cmd, int disk_num, int block_num)
{
  uint32_t op = 0;
  op |= cmd << 26;
  op |= disk_num << 22;
  op |= block_num;

  return op;
}

// Disk Mount
int mdadm_mount(void)
{
  if (jbod_client_operation(encodeOp(JBOD_MOUNT, 0, 0), NULL) == 0)
  {
    is_mounted = 1;
    return 1;
  }
  else
  {
    return -1;
  }
}

// Disk Unmount
int mdadm_unmount(void)
{
  if (jbod_client_operation(encodeOp(JBOD_UNMOUNT, 0, 0), NULL) == 0)
  {
    is_mounted = 0;
    return 1;
  }
  else
  {
    return -1;
  }
}
void translate_address(uint32_t addr, int *disk_num, int *block_num, int *offset)
{
  *disk_num = addr / JBOD_DISK_SIZE;
  int disk_offset = addr % JBOD_DISK_SIZE;
  *block_num = disk_offset / JBOD_BLOCK_SIZE;
  *offset = disk_offset % JBOD_BLOCK_SIZE;
}
int min(int n1, int n2)
{
  if (n1 < n2)
  {
    return n1;
  }
  else
  {
    return n2;
  }
}

// Retrieves Data from Disk
int mdadm_read(uint32_t addr, uint32_t len, uint8_t *buf)
{
  if ((addr + len > (JBOD_DISK_SIZE * JBOD_NUM_DISKS)) || (buf == NULL && len != 0) || len > 1024 || is_mounted == 0)
  {
    return -1;
  }
  else if (len == 0 && buf == NULL)
  {
    return len;
  }
  int disk_num;
  int block_num;
  int offset;
  int length = len;
  int num_bytes_to_read_from_block;
  int num_read = 0;
  uint8_t mybuf[256];

  // Read Disk Only
  while (num_read != length)
  {
    translate_address(addr, &disk_num, &block_num, &offset);

    if (cache_enabled() && cache_lookup(disk_num, block_num, mybuf) == 1)
    {
      num_bytes_to_read_from_block = min(len, min(256, 256 - offset));
      memcpy(buf + num_read, mybuf + offset, num_bytes_to_read_from_block);
      num_read += num_bytes_to_read_from_block;
      len -= num_bytes_to_read_from_block;
      addr += num_bytes_to_read_from_block;
    }
    else
    {
      jbod_client_operation(encodeOp(JBOD_SEEK_TO_DISK, disk_num, 0), NULL);
      jbod_client_operation(encodeOp(JBOD_SEEK_TO_BLOCK, 0, block_num), NULL);
      jbod_client_operation(encodeOp(JBOD_READ_BLOCK, 0, 0), mybuf);

      if (cache_enabled())
      {
        cache_insert(disk_num, block_num, mybuf);
      }
      num_bytes_to_read_from_block = min(len, min(256, 256 - offset));
      memcpy(buf + num_read, mybuf + offset, num_bytes_to_read_from_block);
      num_read += num_bytes_to_read_from_block;
      len -= num_bytes_to_read_from_block;
      addr += num_bytes_to_read_from_block;
    }
  }

  return length;
}
int mdadm_write(uint32_t addr, uint32_t len, const uint8_t *buf)
{
  if ((addr + len > (JBOD_DISK_SIZE * JBOD_NUM_DISKS)) || (buf == NULL && len != 0) || len > 1024 || is_mounted == 0)
  {
    return -1;
  }
  else if (len == 0 && buf == NULL)
  {
    return len;
  }
  int disk_num;
  int block_num;
  int offset;
  int length = len;
  int num_bytes_to_write_to_block;
  int num_written = 0;
  uint8_t mybuf[256];

  // Write Disk Only
  while (num_written != length)
  {
    translate_address(addr, &disk_num, &block_num, &offset);
    num_bytes_to_write_to_block = min(len, min(256, 256 - offset));

    if (cache_enabled() && cache_lookup(disk_num, block_num, mybuf) == 1)
    {
      memcpy(mybuf + offset, buf + num_written, num_bytes_to_write_to_block);

      jbod_client_operation(encodeOp(JBOD_SEEK_TO_DISK, disk_num, 0), NULL);
      jbod_client_operation(encodeOp(JBOD_SEEK_TO_BLOCK, 0, block_num), NULL);
      jbod_client_operation(encodeOp(JBOD_WRITE_BLOCK, 0, 0), mybuf);

      cache_update(disk_num, block_num, mybuf);
    }
    else
    {
      jbod_client_operation(encodeOp(JBOD_SEEK_TO_DISK, disk_num, 0), NULL);
      jbod_client_operation(encodeOp(JBOD_SEEK_TO_BLOCK, 0, block_num), NULL);
      jbod_client_operation(encodeOp(JBOD_READ_BLOCK, 0, 0), mybuf);

      memcpy(mybuf + offset, buf + num_written, num_bytes_to_write_to_block);

      jbod_client_operation(encodeOp(JBOD_SEEK_TO_DISK, disk_num, 0), NULL);
      jbod_client_operation(encodeOp(JBOD_SEEK_TO_BLOCK, 0, block_num), NULL);
      jbod_client_operation(encodeOp(JBOD_WRITE_BLOCK, 0, 0), mybuf);
    }

    num_written += num_bytes_to_write_to_block;
    len -= num_bytes_to_write_to_block;
    addr += num_bytes_to_write_to_block;
  }

  return length;
}